-- Credits By Fume
-- My Comunity Discord ESX: discord.me/sagresroleplayesxpt
-- My Comunity Discord VRP: discord.me/sagresroleplaypt
-- My Discord: Fume#0581

Locales['en'] = {
  ['dominacao_de_bairros'] = 'Dominação de Bairro',
  ['pressiona_para_dominar'] = 'Pressiona ~INPUT_CONTEXT~ para ~o~Dominar este Bairro~s~ ~b~%s~s~',
  ['tempo_para_a_dominacao_acabar'] = 'Dominação de Bairros: ~r~%s~s~ Segundos para Acabar',
  ['recentemente_dominada'] = 'Este Bairro Foi Recentemente Dominado. Por Favor Espere ~y~%s~s~ Segundos para Poder Dominar.',
  ['dominacao_em_progresso_em'] = '~r~Dominação em Progresso Em ~b~%s~s~',
  ['comecaste_a_dominar'] = 'Tu Começas-te a Dominar ~y~%s~s~',
  ['alarme_foi_disparado'] = 'O Alarme Foi Disparado',
  ['dominacao_completa'] = '~r~A Dominação Foi Sucedida~s~, Tu ~o~Ganhas-te~s~ ~g~€%s~s~',
  ['dominacao_bem_sucedida_em'] = '~r~Dominação Bem Sucedida em ~y~%s~s~',
  ['dominacao_cancelada'] = 'A Dominação foi Cancelada!',
  ['dominacao_cancelada_em'] = '~r~A Dominação em ~b~%s~s~ Foi Cancelada!',
  ['minimo_de_gang'] = 'Precisa de ~b~%s Gangs/Mafias etc~s~ para começar a Dominação.',
  ['dominacao_a_bairro_em_processo'] = '~r~Dominação a Bairro em Processo.',
  ['nao_es_uma_ameaca'] = 'Tu Não Representas Ameaça para este Lugar. Tens de Ter uma Arma na Mão.',
}
